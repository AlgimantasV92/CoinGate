package Testai;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dovanu_Kuponai {
	
	@Test 
	public void Login() throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://coingate.com");


     
        Thread.sleep(1000);
 		
 		driver.findElement(By.xpath("//*[@id=\"page-container\"]/header/div/div[1]/nav/ul/li[1]/a")).click();
    	
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"page-container\"]/header/div/div[1]/nav/ul/li[1]/div/a[4]/div[1]")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"intro\"]/div[2]/div/div[2]/a")).click();
		
        Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[@id=\"page-container\"]/main/div/div[1]/div[2]/div[2]/div[1]/div")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.id("add-to-cart")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/div[3]/a")).click();
		
		Thread.sleep(3500);
		
		driver.findElement(By.name("cart[email]")).click();
		driver.findElement(By.name("cart[email]")).sendKeys("algimantas.vaic@gmail.com");
		
		Thread.sleep(1000);
		
		driver.findElement(By.name("cart[terms]")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"checkouting\"]/div[1]/div/div[1]/div/div/div[3]/a")).click();
		
        Thread.sleep(1000);
		
        driver.findElement(By.xpath("//*[@id=\"register\"]")).click();
		
		Thread.sleep(6000);
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div/div[2]/div[2]/div/div/label[1]/span[2]/div[1]")).click();
		
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div/div[2]/div[3]/div/div[2]/div")).click();
		
        Thread.sleep(1000);
        
        driver.findElement(By.name("email")).click();
		driver.findElement(By.name("email")).sendKeys("algimantas.vaic@gmail.com");
		
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div/div[2]/div[3]/div/div[2]/div/button[1]")).click();
		
		Thread.sleep(9000);
		
		driver.close();
	}
	
}
